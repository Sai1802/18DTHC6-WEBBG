﻿namespace WEBBG.Controllers
{
    internal class DataClasses1
    {
    }
}